package com.example.ortalamahesaplama;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText quizInput;
    private EditText finalInput;
    private TextView averageOutput;
    private TextView gradeOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        quizInput = findViewById(R.id.quizInput);
        finalInput = findViewById(R.id.finalInput);
        averageOutput = findViewById(R.id.averageOutput);
        gradeOutput = findViewById(R.id.gradeOutput);
        Button calculateButton = findViewById(R.id.calculateButton);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateAverage();
            }
        });
    }

    private void calculateAverage() {
        String quizText = quizInput.getText().toString();
        String finalText = finalInput.getText().toString();

        if (quizText.isEmpty() || finalText.isEmpty()) {
            averageOutput.setText("Ortalama: Eksik Veri");
            gradeOutput.setText("Harf Notu: Eksik Veri");
            return;
        }

        double quizScore = Double.parseDouble(quizText);
        double finalScore = Double.parseDouble(finalText);

        // Ortalama hesaplama: Vize notunun %40'ı + Final notunun %60'ı
        double average = (quizScore * 0.4) + (finalScore * 0.6);
        averageOutput.setText("Ortalama: " + String.format("%.2f", average));

        // Harf notu hesaplama
        String grade;
        if (average >= 90) {
            grade = "AA";
        } else if (average >= 85) {
            grade = "BA";
        } else if (average >= 80) {
            grade = "BB";
        } else if (average >= 75) {
            grade = "CB";
        } else if (average >= 70) {
            grade = "CC";
        } else if (average >= 65) {
            grade = "DC";
        } else if (average >= 60) {
            grade = "DD";
        } else if (average >= 50) {
            grade = "FD";
        } else {
            grade = "FF";
        }
        gradeOutput.setText("Harf Notu: " + grade);
    }
}
